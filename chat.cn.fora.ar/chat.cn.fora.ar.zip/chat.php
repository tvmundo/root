<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<html>
<head>
<title>Bate Papo</title>
<META HTTP-EQUIV="Refresh" CONTENT="50;URL=chat.php">
<script language="javascript">
function ultima() {
location.href = "#ultima";
}
</script>
</head>
<body bgcolor="#ffffff" /* #ffffff */  onLoad="javascript:ultima()">
<font face="Verdana" size="2">
<?php include("chat.txt"); ?>
<a name="ultima"> </a>
</font>
</body>
</html>