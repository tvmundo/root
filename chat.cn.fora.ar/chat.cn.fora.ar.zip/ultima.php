<html>
<head>
<META HTTP-EQUIV="Refresh" CONTENT="5;URL=ultima.php">
</head>
<body bgcolor="#000" /* #C92E01 */ ><font face="Verdana" size="2" color="white">
<b>�ltima mensagem enviada �s <?php include("ultima.txt"); ?>.</b></font>
</body>
</html>