<head>
<title> atendimento  eitabirano</title>
</head>
<div id="bloco_do_lado_do_slider">

<div class="enquete_no_bloco_la_encima">
<script language="JavaScript">
function abrir(URL) {

  var width = 420;
  var height = 600;

  var left = 99;
  var top = 0;

  window.open(URL,'janela', 'width='+width+', height='+height+', top='+top+', left='+left+', scrollbars="no", status="no", toolbar="no", location="no", directories="no", menubar="no", resizable="no", fullscreen=no');

}
</script>
<a href="javascript:abrir('entrar.php');">atendimento online</font></a>